Movement Controls

W 				- Move forward
A				- Enable left side ship thruster
S 				- Move backwards
D 				- Enable right side ship thruster

SPACE			- Shoot

UP ARROW		- Move Up in the menus
DOWN ARROW 		- Move Down in the menus
ENTER			- Select button in the menus